# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.
here is the link https://github.com/udacity/fend/tree/refresh-2019/projects/landing-page 

you need to install atom or visual studio code to run the project in it 
the project contains css file for the design of the page js file to make the page dynamic and html the content of file you need to run index.html to see the project in chrome or internet explorer 
this website will help you in anything you want : https://www.w3schools.com/
