
var i = 0;
var sections =  document.querySelectorAll('section');
document.addEventListener("click", function(){
  i++;
  if ( i==1){
  alert("Welcome To Our Landing Page :)");}
 });


const sectionsElements = document.querySelectorAll('section');
const navbarUl = document.getElementById('navbar__list');
var navList ='';



  window.addEventListener("scroll" , function (event){
    sections.forEach(x => {
      const reactp = x.getBoundingClientRect().top;
      console.log(reactp)
      if (reactp < 150 && reactp >= -150 )
      {
        x.style.background= "blue"; 
      }
      else {
        x.style.cssText = "background-color: linear-gradient( rgb ";
      }
      
    });
},);


// build the nav
function gernerateNavbar() {
  sectionsElements.forEach((section) => {
    // add html tags for list items
    // dataset.nav returns DOMStringMap {nav: section 1}
    navList += `<li> <a class="nav__link menu__link" href="#${section.id}" id="navli">
          ${section.dataset.nav}</a></li>`;
  });
  // add the tags to the inner htmls
  navbarUl.innerHTML = navList;
}
gernerateNavbar();
// Add class 'active' to section when near top of viewport


// function to add active section
function add11()
{
  document.getElementById("landing-title").classList.add("mystyle", "anotherClass", "thirdClass");
}

function remove11()
{
  document.getElementById("landing-title").classList.remove("mystyle", "anotherClass", "thirdClass");
}
// Scroll to anchor ID using scrollTO event

function scroll11()
{
  var elmnt = document.getElementById("section4");
  elmnt.scrollIntoView();
}
